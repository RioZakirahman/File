import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class historyForm extends JInternalFrame {
	
	JTable historyHeaderTbl, historyDetailTbl;
	DefaultTableModel historyHeaderModel, historyDetailModel;
	JScrollPane historyHeaderScroll, historyDetailScroll;
	JPanel historyHeaderTblPnl, historyDetailTblPnl;
	
	private Connect con = Connect.getConnection();
	
	public void init() {
		//Column name
		Vector<Object> historyHeaderColumn = new Vector<>();
		historyHeaderColumn.add("ID");
		historyHeaderColumn.add("Total Purchase (IDR)");
		historyHeaderColumn.add("date Purchase");
		
		Vector<Object> historyDetailColumn = new Vector<>();
		historyDetailColumn.add("History ID");
		historyDetailColumn.add("Music Name");
		historyDetailColumn.add("Music Artist");
		historyDetailColumn.add("Music Price (IDR)");
		
		//DefaultTableModel
		historyHeaderModel = new DefaultTableModel(historyHeaderColumn,0);
		historyDetailModel = new DefaultTableModel(historyDetailColumn,0);
		
		//Table
		historyHeaderTbl = new JTable(historyHeaderModel);
		historyDetailTbl = new JTable(historyDetailModel);
		
		//ScrollPane
		historyHeaderScroll = new JScrollPane(historyHeaderTbl);
		historyHeaderScroll.setPreferredSize(new Dimension(500, 700));
		historyDetailScroll = new JScrollPane(historyDetailTbl);
		historyDetailScroll.setPreferredSize(new Dimension(500, 700));
		
		
		//Panel
		historyHeaderTblPnl = new JPanel();
		historyDetailTblPnl = new JPanel();
		
		
		//Add comp to panel
		historyHeaderTblPnl.add(historyHeaderScroll);
		historyDetailTblPnl.add(historyDetailScroll);
		
	}
	
	public void loadData(ResultSet rs) {
		try {
			while (rs.next()) {
				int id = rs.getInt("id");
				String total_purchase = rs.getString("total_purchase");
				String date_purchase = rs.getString("date_purchase");
		
				
				Vector<Object> data = new Vector<>();
				
				data.add(id);
				data.add(total_purchase);
				data.add(date_purchase);
	
				
				historyHeaderModel.addRow(data);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void loadHistory(ResultSet rs) {
		try {
			while (rs.next()) {
				int historyID = rs.getInt("history_header.id");
				String music_name = rs.getString("musics.music_name");
				String artist = rs.getString("musics.music_artist_name");
				int price = rs.getInt("musics.music_price");
				
				Vector<Object> data = new Vector<>();
				data.add(historyID);
				data.add(music_name);
				data.add(artist);
				data.add(price);
		
				historyDetailModel.addRow(data);
			
				
				
				
				
			
				
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	public void listener() {
		historyHeaderTbl.addMouseListener(new MouseListener() {
			
			int selectedRowIndex ;

			@Override
			public void mouseReleased(MouseEvent e) {
				historyDetailModel.setRowCount(0);
				 selectedRowIndex = historyHeaderTbl.getSelectedRow();
				
			
					int id = Integer.valueOf(historyHeaderModel.getValueAt(selectedRowIndex,0).toString());
					
					loadHistory(con.executeQuery("SELECT * FROM history_header JOIN history_detail ON history_header.id = history_detail.history_id JOIN musics ON history_detail.music_id = musics.id WHERE history_header.id = " + id
							));
				
				
				
	
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
			
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
			
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
		
				
			}
		});
	}
	
	public void internalFrame() {
		init();
		loadData(con.executeQuery("SELECT * FROM history_header"));
		listener();
		setVisible(true);
		setSize(1050,800);
		setIconifiable(true);
		setClosable(true);
		setLayout(new GridLayout(1,2));
		add(historyHeaderTblPnl);
		add(historyDetailTblPnl);
	}
	
	public historyForm() {
		internalFrame();
	}

}
