import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
//import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;



public class Login extends JFrame  {
	JPanel titlePnl, centerPnl, emailTxtPnl,passwordTxtPnl, loginBtnPnl, registerBtnPnl, emailPnl,passwordPnl;
	JLabel title,email,password, backgroundColorLbl;
	JTextField emailTxt;
	JPasswordField passwordTxt;
	JButton loginBtn, registerBtn;

	public static int userId;
	
	private Connect con = Connect.getConnection();
	
	public void init() {
		
		
		//init Label
		title = new JLabel("LOGIN");
		email = new JLabel("Email");
		password = new JLabel("Password");
			
		//set Label
		title.setFont(new Font("Arial", Font.BOLD, 26));
		title.setForeground(Color.white);
		email.setPreferredSize(new Dimension(170,30));
		email.setForeground(Color.white);
		password.setPreferredSize(new Dimension(170,30));
		password.setForeground(Color.white);
		
		//init TextField
		emailTxt = new JTextField();
		passwordTxt = new JPasswordField();
		
		//set TextField
		emailTxt.setPreferredSize(new Dimension(180,30));
		emailTxt.setBorder(null);
		passwordTxt.setPreferredSize(new Dimension(180,30));
		passwordTxt.setBorder(null);
		
		//init Button
		loginBtn = new JButton("Login");
		registerBtn = new JButton("I dont have an account!");
		
		//set Button
		loginBtn.setPreferredSize(new Dimension(200,40));
		loginBtn.setBackground(new Color(255,175,175,255));
		loginBtn.setForeground(Color.white);
		loginBtn.setBorder(null);
		loginBtn.setFocusPainted(false);
		registerBtn.setPreferredSize(new Dimension(200,40));
		registerBtn.setBackground(new Color(255,175,175,255));
		registerBtn.setForeground(Color.white);
		registerBtn.setBorder(null);
		registerBtn.setFocusPainted(false);
		
		//init Panel
		emailPnl = new JPanel();
		passwordPnl = new JPanel();
		loginBtnPnl = new JPanel();
		registerBtnPnl = new JPanel();
		passwordTxtPnl = new JPanel();
		emailTxtPnl = new JPanel();
		titlePnl = new JPanel();
		centerPnl = new JPanel(new GridLayout(3,2,0,-80));
		
		//add component to Panel
		emailPnl.add(email);
		passwordPnl.add(password);
		loginBtnPnl.add(loginBtn);
		registerBtnPnl.add(registerBtn);
		passwordTxtPnl.add(passwordTxt);
		emailTxtPnl.add(emailTxt);
		titlePnl.add(title);
		centerPnl.add(emailPnl);
		centerPnl.add(emailTxtPnl);
		centerPnl.add(passwordPnl);
		centerPnl.add(passwordTxtPnl);
		centerPnl.add(loginBtnPnl);
		centerPnl.add(registerBtnPnl);
		
		//set Panel
		emailPnl.setOpaque(false);
		passwordPnl.setOpaque(false);
		loginBtnPnl.setOpaque(false);
		registerBtnPnl.setOpaque(false);
		passwordTxtPnl.setOpaque(false);
		emailTxtPnl.setOpaque(false);
		titlePnl.setOpaque(false);
		centerPnl.setOpaque(false);
		
	}
	
	public void registerBtnListener() {
		
		registerBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e)  {
				//Register Form
				
				new Register();
				dispose();
			
			}
		});
	}
	
	public void loginBtnListener() {
		loginBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(emailTxt.getText().isEmpty()) {
					//validation empty email
					JOptionPane.showMessageDialog(null, "Please input email", "Alert", JOptionPane.WARNING_MESSAGE);
				} else if(passwordTxt.getPassword().length == 0) {
					//validation empty password
					JOptionPane.showMessageDialog(null,"Please input password","Alert", JOptionPane.WARNING_MESSAGE);
				} else {
					String pass = passwordTxt.getText();
					String email  = emailTxt.getText();
					String query = "SELECT * FROM users WHERE email = '" + email + "'" + "and password = " + "'" + pass + "'" ;
					validationData(con.executeQuery(query));
					
				}
				//validation email & password
				//validation role
				
				
			}
		});
	}
	
	public void validationData(ResultSet rs) {
		try {
				if (rs.next()) {
					userId = rs.getInt("id");
					int role = rs.getInt("role");
					if (role == 1) {
						System.out.println("Role adalah admin" );
					} else if (role == 2) {
						JOptionPane.showMessageDialog(null, "Welcome, " + rs.getString("username"));
						dispose();
						new userMainForm();
					}
				} else {
					JOptionPane.showMessageDialog(null,"Invalid email or password!","Alert", JOptionPane.WARNING_MESSAGE);
				}
				
				
		
			
		} catch (SQLException e) {
			System.out.println("pass salah");
			e.printStackTrace();
		}
	}
	
	public String encrypt(String input) {
		String value = "";
		char [] chars = input.toCharArray();
		int key = 18;
		for (char c : chars) {
			c += key;
			value += String.valueOf(c);
		}
		return value;
	}
	
	public void frame() {
		init();
		registerBtnListener();
		loginBtnListener();
		JPanel mainPanel = new JPanel(new BorderLayout());
		setSize(450,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setTitle("Clay's Music Store");
		add(mainPanel);

		mainPanel.setBackground(new Color(67,67,67));
		mainPanel.add(titlePnl, BorderLayout.NORTH);
		mainPanel.add(centerPnl, BorderLayout.CENTER);
		
		

		
		
	}
	
	public Login() {
		frame();
	}

}
