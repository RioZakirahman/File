import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class Register extends JFrame {
	
	JLabel title,username,email,password,confirmPass,gender;
	JTextField usernameTxt, emailTxt;
	JPasswordField passwordTxt,confirmPassTxt;
	JRadioButton male,female;
	JButton registerBtn,loginBtn;
	ButtonGroup genderGroup;
	JPanel titlePnl, centerPnl, usernamePnl, usernameTxtPnl, emailPnl,emailTxtPnl,passwordPnl,passwordTxtPnl, confirmPassPnl,confirmPassTxtPnl, genderLblPnl, genderPnl,malePnl,femalePnl, registerBtnPnl,loginBtnPnl;
	
	Connect con = Connect.getConnection();
	
	public void init() {
		//Button
		registerBtn = new JButton("Register");
		loginBtn = new JButton("I Have an account");
		
		//set Button
		registerBtn.setPreferredSize(new Dimension(200,40));
		registerBtn.setBackground(new Color(255,175,175,255));
		registerBtn.setForeground(Color.white);
		registerBtn.setBorder(null);
		registerBtn.setFocusPainted(false);
		
		loginBtn.setPreferredSize(new Dimension(200,40));
		loginBtn.setBackground(new Color(255,175,175,255));
		loginBtn.setForeground(Color.white);
		loginBtn.setBorder(null);
		loginBtn.setFocusPainted(false);
		
		//Radio Button
		male = new JRadioButton("Male");
		male.setActionCommand("male");
		male.setSelected(true);
		female = new JRadioButton("Female");
		female.setActionCommand("female");
		
		//set Radio Button
		male.setOpaque(false);
		male.setForeground(Color.white);
		male.setFocusPainted(false);
		
		female.setOpaque(false);
		female.setForeground(Color.white);
		female.setFocusPainted(false);
		
		//Label
		title = new JLabel("Register");
		username = new JLabel("Username");
		email = new JLabel("Email");
		password = new JLabel("Password");
		confirmPass = new JLabel("Confirm Password");
		gender = new JLabel("Gender");
		
		//set Label
		title.setFont(new Font("Arial", Font.BOLD, 22));
		title.setForeground(Color.white);
		username.setForeground(Color.white);
		username.setPreferredSize(new Dimension(120,30));
		email.setForeground(Color.white);
		email.setPreferredSize(new Dimension(120,30));
		password.setForeground(Color.white);
		password.setPreferredSize(new Dimension(120,30));
		confirmPass.setForeground(Color.white);
		confirmPass.setPreferredSize(new Dimension(120,30));
		gender.setForeground(Color.white);
		gender.setPreferredSize(new Dimension(120,30));
		
		//TextField
		usernameTxt = new JTextField();
		emailTxt = new JTextField();
		passwordTxt = new JPasswordField();
		confirmPassTxt = new JPasswordField();
		
		//set TextField
		usernameTxt.setPreferredSize(new Dimension(180,30));
		usernameTxt.setBorder(null);
		emailTxt.setPreferredSize(new Dimension(180,30));
		emailTxt.setBorder(null);
		passwordTxt.setPreferredSize(new Dimension(180,30));
		passwordTxt.setBorder(null);
		confirmPassTxt.setPreferredSize(new Dimension(180,30));
		confirmPassTxt.setBorder(null);
		
		//Panel
		titlePnl = new JPanel();
		usernamePnl = new JPanel();
		usernameTxtPnl = new JPanel();
		emailPnl = new JPanel();
		emailTxtPnl = new JPanel();
		centerPnl = new JPanel(new GridLayout(6,2,-20,-20));
		passwordPnl = new JPanel();
		passwordTxtPnl = new JPanel();
		confirmPassPnl = new JPanel();
		confirmPassTxtPnl = new JPanel();
		malePnl = new JPanel();
		femalePnl = new JPanel();
		genderLblPnl = new JPanel();
		genderPnl = new JPanel( new GridLayout(1,2));
		registerBtnPnl = new JPanel();
		loginBtnPnl = new JPanel();
		
		//Add component to panel
		titlePnl.add(title);
		usernamePnl.add(username);
		emailPnl.add(email);
		emailTxtPnl.add(emailTxt);
		usernameTxtPnl.add(usernameTxt);
		passwordPnl.add(password);
		passwordTxtPnl.add(passwordTxt);
		confirmPassPnl.add(confirmPass);
		confirmPassTxtPnl.add(confirmPassTxt);
		registerBtnPnl.add(registerBtn);
		loginBtnPnl.add(loginBtn);
		genderLblPnl.add(gender);
		malePnl.add(male);
		femalePnl.add(female);
		centerPnl.add(usernamePnl);
		centerPnl.add(usernameTxtPnl);
		centerPnl.add(emailPnl);
		centerPnl.add(emailTxtPnl);
		centerPnl.add(passwordPnl);
		centerPnl.add(passwordTxtPnl);
		centerPnl.add(confirmPassPnl);
		centerPnl.add(confirmPassTxtPnl);
		centerPnl.add(genderLblPnl);
		centerPnl.add(genderPnl);
		centerPnl.add(registerBtnPnl);
		centerPnl.add(loginBtnPnl);
		genderPnl.add(malePnl);
		genderPnl.add(femalePnl);
		
		
		//set Panel
		titlePnl.setOpaque(false);
		usernamePnl.setOpaque(false);
		emailPnl.setOpaque(false);
		centerPnl.setOpaque(false);
		usernameTxtPnl.setOpaque(false);
		emailTxtPnl.setOpaque(false);
		passwordPnl.setOpaque(false);
		passwordTxtPnl.setOpaque(false);
		confirmPassPnl.setOpaque(false);
		confirmPassTxtPnl.setOpaque(false);
		genderLblPnl.setOpaque(false);
		genderPnl.setOpaque(false);
		malePnl.setOpaque(false);
		femalePnl.setOpaque(false);
		registerBtnPnl.setOpaque(false);
		loginBtnPnl.setOpaque(false);
		
		//Button Group
		genderGroup = new ButtonGroup();
		genderGroup.add(male);
		genderGroup.add(female);
		
		
	}
	
	public void frame() {
		init();
		loginBtnListener();
		registerBtnListener();
		JPanel mainPanel = new JPanel(new BorderLayout());
		setSize(450,400);
		setVisible(true);
		setLocationRelativeTo(null);
		setResizable(false);
		setTitle("Register Form");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add(mainPanel);
		mainPanel.setBackground(new Color(67,67,67));
		mainPanel.add(titlePnl, BorderLayout.NORTH);
		mainPanel.add(centerPnl, BorderLayout.CENTER);
		
	}
	
	public void loginBtnListener() {
		loginBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Login();
				dispose();
			}
		});
	}
	
	public void insertData() {
		String uname = usernameTxt.getText();
		String email = emailTxt.getText();
		int domain = email.indexOf(".");
		int atSign = email.indexOf("@");
		int end = email.length()- 1;
		String pass  = passwordTxt.getText();
		String confirmPass = confirmPassTxt.getText();
		String gender = genderGroup.getSelection().getActionCommand();
		int role = 2;
		
		if (uname.isEmpty()) {
			JOptionPane.showMessageDialog(null,"Username cannot be empty!","Alert", JOptionPane.WARNING_MESSAGE);
		} else if (email.indexOf('.',atSign) == -1) {
			JOptionPane.showMessageDialog(null,"Please input a valid email!","Alert", JOptionPane.WARNING_MESSAGE);
		} else if (email.indexOf('@',domain) != -1) {
			JOptionPane.showMessageDialog(null,"Please input a valid email!","Alert", JOptionPane.WARNING_MESSAGE);
		} else if (email.lastIndexOf('.') == end && email.indexOf('@') == 0) {
			JOptionPane.showMessageDialog(null,"Please input a valid email!","Alert", JOptionPane.WARNING_MESSAGE);		
		} else if (!(email.contains("@"))) {
			JOptionPane.showMessageDialog(null,"Please input a valid email!","Alert", JOptionPane.WARNING_MESSAGE);		
		} 
		  else if (pass.isEmpty()) {
			JOptionPane.showMessageDialog(null,"Password cannot be empty!","Alert", JOptionPane.WARNING_MESSAGE);
		} else if (confirmPass.isEmpty()) {
			JOptionPane.showMessageDialog(null,"Confirmation password cannot be empty!","Alert", JOptionPane.WARNING_MESSAGE);
				
		} else if (!(confirmPass.equals(pass))) {
			JOptionPane.showMessageDialog(null,"Password must be same with the confirmation password!","Alert", JOptionPane.WARNING_MESSAGE);
		} else {
			String query = "INSERT INTO users VALUES ( NULL," + "'" + uname + "'," + "'" + email + "'," + "'" + pass + "'," + role +  ",'" + gender + "')"  ;
			con.executeUpdate(query);
			dispose();
			new Login();
		}
		
	}

	public void registerBtnListener() {
		registerBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				insertData();
			}
		});
	}
	
	public Register() {
		frame();
	}
	
	
}
