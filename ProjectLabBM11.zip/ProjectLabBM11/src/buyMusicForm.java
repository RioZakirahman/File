import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class buyMusicForm extends JInternalFrame {
	
	JPanel leftPnl,musicTblPnl,addCartBtnPnl,rightPnl, cartTblPnl, removeBtnPnl, buyBtnPnl, thirdPnl, visibleBtnPnl ;
	JTable musicTbl, cartTbl;
	JButton addCart, removeBtn, buyBtn, visibleBtn;
	DefaultTableModel model;
	DefaultTableModel cartModel;
	JScrollPane musicTblScroll, cartTblScroll;
	
	private int userId = Login.userId;
	int history_id = 0;
	
	private Connect con = Connect.getConnection();
	
	public void init() {
		
		Vector<Object> header = new Vector<>();
		header.add("ID");
		header.add("Name");
		header.add("Genre");
		header.add("Price");
		header.add("Artist Name");
		header.add("Release Date");
		
		
		//Button
		addCart = new JButton("Add To Chart");
		addCart.setPreferredSize(new Dimension(500,30));
		removeBtn = new JButton("Remove From Cart");
		removeBtn.setPreferredSize(new Dimension(500,30));
		buyBtn = new JButton("Buy");
		buyBtn.setPreferredSize(new Dimension(245,30));
		visibleBtn = new JButton();
		visibleBtn.setVisible(false);
		
		
		//Panel
		buyBtnPnl = new JPanel();
		leftPnl = new JPanel();
		musicTblPnl = new JPanel();
		addCartBtnPnl = new JPanel();
		rightPnl = new JPanel();
		cartTblPnl = new JPanel();
		removeBtnPnl = new JPanel();
		thirdPnl = new JPanel(new GridLayout(1,2));
		visibleBtnPnl = new JPanel();
		
		//DefaultTableModel
		model = new DefaultTableModel(header,0);
		cartModel = new DefaultTableModel(header,0);
		
		//Table
		musicTbl = new JTable(model) {
	
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		cartTbl = new JTable(cartModel);
		
		
		//ScrollPane
		musicTblScroll = new JScrollPane(musicTbl);
		musicTblScroll.setPreferredSize(new Dimension(500, 600));

		cartTblScroll = new JScrollPane(cartTbl);
		cartTblScroll.setPreferredSize(new Dimension(500, 600));
		
		
		
		//add Comp to panel
		buyBtnPnl.add(buyBtn);
		addCartBtnPnl.add(addCart);
		cartTblPnl.add(cartTblScroll);
		removeBtnPnl.add(removeBtn);
		musicTblPnl.add(musicTblScroll);
		visibleBtnPnl.add(visibleBtn);
		thirdPnl.add(visibleBtnPnl);
		thirdPnl.add(buyBtnPnl);
		leftPnl.add(musicTblPnl);
		leftPnl.add(addCartBtnPnl);
		rightPnl.add(cartTblPnl);
		rightPnl.add(removeBtnPnl);
		rightPnl.add(thirdPnl);

		
		
		
	}
	
	public void loadData(ResultSet rs) {
		try {
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("music_name");
				String genre = rs.getString("genre_name");
				String price = rs.getString("music_price");
				String artist = rs.getString("music_artist_name");
				String release_date = rs.getString("release_date");
				
				Vector<Object> data = new Vector<>();
				
				data.add(id);
				data.add(name);
				data.add(genre);
				data.add(price);
				data.add(artist);
				data.add(release_date);
				
				model.addRow(data);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getCurrentDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
		Date date = new Date();
		String dateFormat = sdf.format(date);
		
		return dateFormat;
	}
		
	public void addCart() {
		addCart.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {

				int selectedRowIndex = musicTbl.getSelectedRow();
				
				if (selectedRowIndex == -1) {
					JOptionPane.showMessageDialog(null, "Please Select Any Music");
				} else {
					Vector<Object> data = new Vector<>();
					data.add(model.getValueAt(selectedRowIndex, 0));
					data.add(model.getValueAt(selectedRowIndex, 1));
					data.add(model.getValueAt(selectedRowIndex, 2));
					data.add(model.getValueAt(selectedRowIndex, 3));
					data.add(model.getValueAt(selectedRowIndex, 4));
					data.add(model.getValueAt(selectedRowIndex, 5));
					
					cartModel.addRow(data);
				}
				
				
			}
		});
		
		
	}
	
	public void removeCart() {
		removeBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int selectedRowIndex = cartTbl.getSelectedRow();
				
				if (selectedRowIndex == -1) {
					JOptionPane.showMessageDialog(null, "Please Select Any Music From Music");
				} else {
					cartModel.removeRow(selectedRowIndex);
				}
				
			}
		});
		
	}
	
	public Integer getCountRow(ResultSet rs) {
		int count_historyId = 0;
		try {
			while (rs.next()) {
				int history_id = rs.getInt("count(id)");
				count_historyId = count_historyId + history_id; 
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return count_historyId ;
	}
	
	public void buy() {
		buyBtn.addActionListener(new ActionListener() {
			int history = 1;
			int price = 0;
			int music_id = 0;
			String date;
			@Override
			public void actionPerformed(ActionEvent e) {
			
			
				int row  = cartModel.getRowCount();
				if (row == 0) {
					
				}else {
					int id = getCountRow(con.executeQuery("SELECT count(id) FROM history_header"));
					history = history + id;
					for (int i = 0; i < cartModel.getRowCount(); i++) {
						price = price + Integer.valueOf(cartModel.getValueAt(i,3).toString());
						
						date = getCurrentDate();
						

				
					}
//					insert into history_header
					String query = "INSERT INTO history_header VALUES( NULL," + price + "," + "'" + date + "'," + userId + ")" ;
					con.executeUpdate(query);
					
					for (int i = 0; i < cartModel.getRowCount(); i++) {
//						insert into history_detail
						music_id = Integer.valueOf(cartModel.getValueAt(i,0).toString());
						String query_toHistorydetail = "INSERT INTO history_detail VALUES(" + history + "," + music_id + ")";	
						con.executeUpdate(query_toHistorydetail);
					}
					

					
					price = 0;
					int rowNumber = cartModel.getRowCount();
					for (int j = rowNumber-1; j>= 0; j--) {
						cartModel.removeRow(j);
						
					}
				}
				
			}
		});
	}
	
	public void internalFrame() {
		init();
		loadData(con.executeQuery("SELECT * FROM musics , music_genres WHERE musics.music_genre_id = music_genres.id"));
		addCart();
		buy();
		removeCart();
		setVisible(true);
		setSize(1050,800);
		setIconifiable(true);
		setClosable(true);
		setLayout(new GridLayout(1,2));
		add(leftPnl);
		add(rightPnl);

		
	}
	
	public buyMusicForm() {
		internalFrame();
	}

	

}
