
public class Main {

	public Main() {
		
		//Login Form
		new Login();
		
		
	}

	public static void main(String[] args) {
		new Main();

	}

}
