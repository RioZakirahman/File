import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.event.MenuListener;

public class userMainForm extends JFrame {
	JMenuBar menuBar;
	JMenu menuUser, menuStore;
	JMenuItem Logoff,buyMusic,history;
	JDesktopPane mainPanel = new JDesktopPane();
	
	public void init() {
		//menubar
		menuBar = new JMenuBar();
		
		//menu
		menuUser = new JMenu("User");
		menuStore = new JMenu("Store");
		
		//menu item
		Logoff = new JMenuItem("Log Off");
		buyMusic = new JMenuItem("Buy Music");
		history = new JMenuItem("History");
		
		menuUser.add(Logoff);	
		menuStore.add(buyMusic);
		menuStore.add(history);
		
		
		menuBar.add(menuUser);
		menuBar.add(menuStore);
		
		
	}
	
	public void menuItemListener() {
	
		Logoff.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Login();
				dispose();
			}
		});
		buyMusic.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				buyMusicForm bmf = new buyMusicForm();
				mainPanel.add(bmf);
			}
		});
		history.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				historyForm hf = new historyForm();
				mainPanel.add(hf);
				
			}
		});
		
	}
	
	public void frame() {
		init();
		menuItemListener();
		setJMenuBar(menuBar);
		setSize(1200,900);
		setVisible(true);
		setLocationRelativeTo(null);
		setResizable(false);
		setTitle("Clay's Music Store");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add(mainPanel);
		
		
	}
	
	public userMainForm() {
		frame();
	}


	
	
	
	

}
